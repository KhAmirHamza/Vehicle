package com.vehicle.driver.utils;

import com.google.firebase.storage.StorageReference;

public abstract class Upload {

    abstract String getImageUrl();
}
