package com.vehicle.driver;

public class Constants {
    public static int BIDDING_TIME_MINUTES = 15;
}
